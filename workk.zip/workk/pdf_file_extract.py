'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

import camelot

def extract_tables_with_titles(pdf_file):


  tables = camelot.read_pdf(pdf_file, pages="all")
  results = []
  for table in tables:
    title = table._title
    if title is not None:
      results.append({"title": title, "table": table.df})
  return results


if __name__ == "__main__":
  pdf_file = "1_Unilever_2022.pdf"
  tables_with_titles = extract_tables_with_titles(pdf_file)
  for table in tables_with_titles:
    print(table)

