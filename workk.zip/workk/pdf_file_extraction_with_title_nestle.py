
import camelot

def extract_tables_with_titles(pdf_file):


  tables = camelot.read_pdf(pdf_file, pages="all")
  results = []
  for table in tables:
    title = table._title
    if title is not None:
      results.append({"title": title, "table": table.df})
  return results


if __name__ == "__main__":
  pdf_file = "2_Nestle_2022.pdf"
  tables_with_titles = extract_tables_with_titles(pdf_file)
  for table in tables_with_titles:
    print(table)

'''
from tabula import read_pdf
from tabulate import tabulate

#reads table from pdf file
df = read_pdf("abc.pdf",pages="all") #address of pdf file
print(tabulate(df))
'''